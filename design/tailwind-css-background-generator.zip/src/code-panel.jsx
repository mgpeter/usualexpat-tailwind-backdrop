// Code panel: builds the HTML output and renders syntax-highlighted, copyable code

function buildOutput({ bgDef, bgOpts, sectionDef, palette, content, dark }) {
  const bg = bgDef.generateCode(bgOpts, palette);
  const sectionMarkup = sectionDef.generateMarkup({ palette, content, dark });

  const wrapperClass = cx("relative overflow-hidden", bg.wrapperClass);
  const wrapperStyle = bg.wrapperStyle ? ` style="${bg.wrapperStyle}"` : '';
  const bgLayers = bg.layers || '';
  const cssBlock = bg.css ? `<style>\n${bg.css}\n</style>\n\n` : '';

  const html = `${cssBlock}<section class="${wrapperClass}"${wrapperStyle}>${bgLayers}
${sectionMarkup}
</section>`;

  return html;
}

const ViewportToggle = ({ value, onChange }) => (
  <div className="flex bg-[#0a0a0b] border border-[var(--border)] rounded-md p-0.5">
    {[
      { id: 'mobile', icon: Icons.smartphone },
      { id: 'tablet', icon: Icons.tablet },
      { id: 'desktop', icon: Icons.monitor },
    ].map(v => (
      <button key={v.id} onClick={() => onChange(v.id)}
        className={cx("px-2.5 py-1.5 rounded text-[var(--fg-dim)] hover:text-[var(--fg)]",
          value === v.id && "bg-[#1f1f23] text-[var(--fg)]")}>
        <v.icon size={13} />
      </button>
    ))}
  </div>
);

const DarkToggle = ({ value, onChange }) => (
  <div className="flex bg-[#0a0a0b] border border-[var(--border)] rounded-md p-0.5">
    <button onClick={() => onChange(false)}
      className={cx("px-2.5 py-1.5 rounded text-[var(--fg-dim)] hover:text-[var(--fg)] flex items-center gap-1.5",
        !value && "bg-[#1f1f23] text-[var(--fg)]")}>
      <Icons.sun size={13} />
      <span className="text-[11px] font-mono">Light</span>
    </button>
    <button onClick={() => onChange(true)}
      className={cx("px-2.5 py-1.5 rounded text-[var(--fg-dim)] hover:text-[var(--fg)] flex items-center gap-1.5",
        value && "bg-[#1f1f23] text-[var(--fg)]")}>
      <Icons.moon size={13} />
      <span className="text-[11px] font-mono">Dark</span>
    </button>
  </div>
);

const CodePanel = ({ html, onCopy, open, onToggle }) => (
  <div className={cx("border-t border-[var(--border)] bg-[#0a0a0b] flex flex-col transition-all",
    open ? "h-[38%]" : "h-10")}>
    <div className="px-5 h-10 flex items-center justify-between shrink-0">
      <button onClick={onToggle}
        className="flex items-center gap-2 hover:text-[var(--fg)] text-[var(--fg-dim)]">
        <Icons.chevronDown size={13} className={cx("transition-transform", !open && "rotate-180")} />
        <Icons.code size={13} />
        <span className="text-[11px] font-mono tracking-wider uppercase">Output · index.html</span>
        <span className="text-[10px] font-mono text-[var(--fg-faint)]">{html.split('\n').length} lines</span>
      </button>
      {open && (
        <button onClick={onCopy}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[11px] font-mono bg-[var(--accent)] text-black hover:opacity-90">
          <Icons.copy size={11} />
          Copy code
        </button>
      )}
    </div>
    {open && (
      <div className="flex-1 overflow-auto px-5 pb-5">
        <pre className="bd-code text-[var(--fg-dim)] whitespace-pre"
          dangerouslySetInnerHTML={{ __html: highlightHtml(html) }} />
      </div>
    )}
  </div>
);

const Toast = ({ message, visible }) => (
  <div className={cx("fixed bottom-6 left-1/2 -translate-x-1/2 z-50 pointer-events-none",
    !visible && "hidden")}>
    <div className={cx("bd-toast-enter px-4 py-2.5 rounded-lg bg-[var(--accent)] text-black text-sm font-medium shadow-2xl flex items-center gap-2")}>
      <Icons.check size={14} strokeWidth={2.5} />
      {message}
    </div>
  </div>
);

window.buildOutput = buildOutput;
window.ViewportToggle = ViewportToggle;
window.DarkToggle = DarkToggle;
window.CodePanel = CodePanel;
window.Toast = Toast;
