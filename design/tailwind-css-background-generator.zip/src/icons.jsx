// Lucide-style stroked icons. Inline SVG. Single source of truth.

const Ico = ({ d, size = 16, strokeWidth = 1.75, ...rest }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" {...rest}>
    {typeof d === 'string' ? <path d={d} /> : d}
  </svg>
);

const Icons = {
  copy: (p) => <Ico {...p} d={<><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></>}/>,
  check: (p) => <Ico {...p} d="M20 6 9 17l-5-5"/>,
  star: (p) => <Ico {...p} d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>,
  starFilled: (p) => <Ico {...p} d={<path d="m12 2 3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/>}/>,
  sun: (p) => <Ico {...p} d={<><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></>}/>,
  moon: (p) => <Ico {...p} d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>,
  monitor: (p) => <Ico {...p} d={<><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></>}/>,
  smartphone: (p) => <Ico {...p} d={<><rect x="5" y="2" width="14" height="20" rx="2.5"/><path d="M12 18h.01"/></>}/>,
  tablet: (p) => <Ico {...p} d={<><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M12 18h.01"/></>}/>,
  chevronDown: (p) => <Ico {...p} d="m6 9 6 6 6-6"/>,
  chevronRight: (p) => <Ico {...p} d="m9 6 6 6-6 6"/>,
  shuffle: (p) => <Ico {...p} d={<><path d="m18 14 4 4-4 4"/><path d="m18 2 4 4-4 4"/><path d="M2 18h1.97a4 4 0 0 0 3.24-1.65l5.58-7.7A4 4 0 0 1 16.04 7H22"/><path d="M2 6h1.97a4 4 0 0 1 3.24 1.65l.79 1.09M22 18h-5.96a4 4 0 0 1-3.24-1.65l-.79-1.09"/></>}/>,
  sliders: (p) => <Ico {...p} d={<><line x1="4" x2="4" y1="21" y2="14"/><line x1="4" x2="4" y1="10" y2="3"/><line x1="12" x2="12" y1="21" y2="12"/><line x1="12" x2="12" y1="8" y2="3"/><line x1="20" x2="20" y1="21" y2="16"/><line x1="20" x2="20" y1="12" y2="3"/><line x1="2" x2="6" y1="14" y2="14"/><line x1="10" x2="14" y1="8" y2="8"/><line x1="18" x2="22" y1="16" y2="16"/></>}/>,
  code: (p) => <Ico {...p} d="m16 18 6-6-6-6M8 6l-6 6 6 6"/>,
  bookmark: (p) => <Ico {...p} d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>,
  trash: (p) => <Ico {...p} d={<><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></>}/>,
  layers: (p) => <Ico {...p} d={<><path d="m12.83 2.18-9.54 4.13a1 1 0 0 0 0 1.84l9.54 4.13a1 1 0 0 0 .77 0l9.54-4.13a1 1 0 0 0 0-1.84L13.6 2.18a1 1 0 0 0-.77 0z"/><path d="m22 17-9.55 4.13a1 1 0 0 1-.77 0L2 17M22 12l-9.55 4.13a1 1 0 0 1-.77 0L2 12"/></>}/>,
  layout: (p) => <Ico {...p} d={<><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></>}/>,
  palette: (p) => <Ico {...p} d="M12 22a1 1 0 0 1-1-1c0-.55.45-1 1-1 .55 0 1-.45 1-1s-.45-1-1-1H9a8 8 0 0 1 0-16c4.42 0 8 3.13 8 7 0 2.76-2.24 5-5 5h-1.5c-.55 0-1 .45-1 1s.45 1 1 1c2.76 0 5-2.24 5-5"/>,
  download: (p) => <Ico {...p} d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>,
  zap: (p) => <Ico {...p} d="m13 2-3 7h6l-3 13"/>,
  plus: (p) => <Ico {...p} d="M12 5v14M5 12h14"/>,
  x: (p) => <Ico {...p} d="M18 6 6 18M6 6l12 12"/>,
  search: (p) => <Ico {...p} d={<><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></>}/>,
};

window.Icons = Icons;
