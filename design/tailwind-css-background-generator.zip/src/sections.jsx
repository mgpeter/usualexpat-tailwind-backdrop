// Section templates: hero, signup, pricing, CTA banner, feature grid.
// Each: { id, name, defaults, render({palette, content, dark}) -> JSX, generateMarkup({palette, content, dark}) -> { html } }

const SECTIONS = [
  {
    id: 'hero-centered',
    name: 'Centered hero',
    defaults: {
      eyebrow: 'NEW · v2.0 RELEASE',
      headline: 'Ship beautiful UI in half the time.',
      sub: 'A backgrounds library and section generator that gets out of your way. Copy, paste, ship.',
      cta1: 'Start building',
      cta2: 'View on GitHub',
    },
    render: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      return (
        <div className="relative z-10 mx-auto max-w-3xl px-6 py-24 text-center">
          {content.eyebrow ? (
            <div className="inline-flex items-center gap-2 rounded-full border px-3 py-1 mb-6 text-xs font-mono tracking-wider"
              style={{ borderColor: dark ? 'rgba(255,255,255,.15)' : 'rgba(0,0,0,.12)', color: fg, background: dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.6)' }}>
              <span className="size-1.5 rounded-full" style={{ background: palette.primary }} />
              {content.eyebrow}
            </div>
          ) : null}
          <h1 className="text-5xl md:text-6xl font-semibold tracking-tight" style={{ color: fg, letterSpacing: '-0.025em' }}>
            {content.headline}
          </h1>
          <p className="mt-6 text-lg" style={{ color: sub }}>{content.sub}</p>
          <div className="mt-10 flex items-center justify-center gap-3">
            <button className="px-5 py-2.5 rounded-lg text-sm font-medium" style={{ background: palette.primary, color: accentText }}>{content.cta1}</button>
            <button className="px-5 py-2.5 rounded-lg text-sm font-medium border" style={{ borderColor: dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)', color: fg }}>{content.cta2}</button>
          </div>
        </div>
      );
    },
    generateMarkup: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      const eyebrow = content.eyebrow ? `
    <div class="inline-flex items-center gap-2 rounded-full border px-3 py-1 mb-6 text-xs font-mono tracking-wider"
         style="border-color:${dark ? 'rgba(255,255,255,.15)' : 'rgba(0,0,0,.12)'};color:${fg};background:${dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.6)'}">
      <span class="size-1.5 rounded-full" style="background:${palette.primary}"></span>
      ${content.eyebrow}
    </div>` : '';
      return `  <div class="relative z-10 mx-auto max-w-3xl px-6 py-24 text-center">${eyebrow}
    <h1 class="text-5xl md:text-6xl font-semibold tracking-tight" style="color:${fg};letter-spacing:-0.025em">
      ${content.headline}
    </h1>
    <p class="mt-6 text-lg" style="color:${sub}">${content.sub}</p>
    <div class="mt-10 flex items-center justify-center gap-3">
      <button class="px-5 py-2.5 rounded-lg text-sm font-medium" style="background:${palette.primary};color:${accentText}">${content.cta1}</button>
      <button class="px-5 py-2.5 rounded-lg text-sm font-medium border" style="border-color:${dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)'};color:${fg}">${content.cta2}</button>
    </div>
  </div>`;
    },
  },

  {
    id: 'hero-signup',
    name: 'Hero + signup',
    defaults: {
      eyebrow: 'EARLY ACCESS',
      headline: 'Backgrounds, born from a single click.',
      sub: 'Join 12,400 designers shipping prettier marketing pages this quarter.',
      placeholder: 'you@company.com',
      cta1: 'Request invite',
    },
    render: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      return (
        <div className="relative z-10 mx-auto max-w-2xl px-6 py-24 text-center">
          {content.eyebrow && (
            <div className="text-xs font-mono tracking-[0.2em] mb-4" style={{ color: palette.primary }}>{content.eyebrow}</div>
          )}
          <h1 className="text-5xl md:text-6xl font-semibold tracking-tight" style={{ color: fg, letterSpacing: '-0.025em' }}>{content.headline}</h1>
          <p className="mt-5 text-base md:text-lg" style={{ color: sub }}>{content.sub}</p>
          <form className="mt-10 mx-auto flex max-w-md gap-2 p-1.5 rounded-full"
            style={{ background: dark ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.7)', border: `1px solid ${dark ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.08)'}` }}>
            <input type="email" placeholder={content.placeholder} className="flex-1 bg-transparent px-4 outline-none text-sm" style={{ color: fg }} />
            <button type="submit" className="px-5 py-2.5 rounded-full text-sm font-medium" style={{ background: palette.primary, color: accentText }}>{content.cta1}</button>
          </form>
          <p className="mt-3 text-xs" style={{ color: dark ? 'rgba(245,245,247,.4)' : 'rgba(10,10,11,.45)' }}>No spam. Unsubscribe any time.</p>
        </div>
      );
    },
    generateMarkup: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      return `  <div class="relative z-10 mx-auto max-w-2xl px-6 py-24 text-center">
    ${content.eyebrow ? `<div class="text-xs font-mono tracking-[0.2em] mb-4" style="color:${palette.primary}">${content.eyebrow}</div>` : ''}
    <h1 class="text-5xl md:text-6xl font-semibold tracking-tight" style="color:${fg};letter-spacing:-0.025em">${content.headline}</h1>
    <p class="mt-5 text-base md:text-lg" style="color:${sub}">${content.sub}</p>
    <form class="mt-10 mx-auto flex max-w-md gap-2 p-1.5 rounded-full"
          style="background:${dark ? 'rgba(255,255,255,.06)' : 'rgba(255,255,255,.7)'};border:1px solid ${dark ? 'rgba(255,255,255,.12)' : 'rgba(0,0,0,.08)'}">
      <input type="email" placeholder="${content.placeholder}" class="flex-1 bg-transparent px-4 outline-none text-sm" style="color:${fg}" />
      <button type="submit" class="px-5 py-2.5 rounded-full text-sm font-medium" style="background:${palette.primary};color:${accentText}">${content.cta1}</button>
    </form>
    <p class="mt-3 text-xs" style="color:${dark ? 'rgba(245,245,247,.4)' : 'rgba(10,10,11,.45)'}">No spam. Unsubscribe any time.</p>
  </div>`;
    },
  },

  {
    id: 'cta-banner',
    name: 'CTA banner',
    defaults: {
      headline: 'Ready to make the web look good again?',
      sub: 'Free during beta.',
      cta1: 'Start free',
      cta2: 'Book a demo',
    },
    render: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      return (
        <div className="relative z-10 mx-auto max-w-5xl px-6 py-20 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-semibold tracking-tight" style={{ color: fg, letterSpacing: '-0.02em' }}>{content.headline}</h2>
            <p className="mt-2" style={{ color: sub }}>{content.sub}</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <button className="px-5 py-2.5 rounded-lg text-sm font-medium" style={{ background: palette.primary, color: accentText }}>{content.cta1}</button>
            <button className="px-5 py-2.5 rounded-lg text-sm font-medium border" style={{ borderColor: dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)', color: fg }}>{content.cta2}</button>
          </div>
        </div>
      );
    },
    generateMarkup: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const accentText = bestTextColor(palette.primary);
      return `  <div class="relative z-10 mx-auto max-w-5xl px-6 py-20 flex flex-col md:flex-row items-center justify-between gap-8">
    <div class="text-center md:text-left">
      <h2 class="text-3xl md:text-4xl font-semibold tracking-tight" style="color:${fg};letter-spacing:-0.02em">${content.headline}</h2>
      <p class="mt-2" style="color:${sub}">${content.sub}</p>
    </div>
    <div class="flex gap-3 shrink-0">
      <button class="px-5 py-2.5 rounded-lg text-sm font-medium" style="background:${palette.primary};color:${accentText}">${content.cta1}</button>
      <button class="px-5 py-2.5 rounded-lg text-sm font-medium border" style="border-color:${dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)'};color:${fg}">${content.cta2}</button>
    </div>
  </div>`;
    },
  },

  {
    id: 'feature-grid',
    name: 'Feature grid',
    defaults: {
      headline: 'Everything in one tiny tool.',
      sub: 'No plugins, no build step. Just markup.',
      f1Title: 'Gradients',
      f1Body: 'Linear, radial, conic. Tweak angle, position, and color stops live.',
      f2Title: 'Patterns',
      f2Body: 'Grids, dots, diagonals — with proper vignette masks baked in.',
      f3Title: 'Animated',
      f3Body: 'Drifting blobs, auroras, scans, cursor spotlights. CSS-only.',
    },
    render: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const cardBg = dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.7)';
      const cardBorder = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
      const features = [
        { t: content.f1Title, b: content.f1Body, c: palette.primary },
        { t: content.f2Title, b: content.f2Body, c: palette.secondary },
        { t: content.f3Title, b: content.f3Body, c: palette.accent },
      ];
      return (
        <div className="relative z-10 mx-auto max-w-6xl px-6 py-24">
          <div className="text-center mb-14 max-w-2xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-semibold tracking-tight" style={{ color: fg, letterSpacing: '-0.02em' }}>{content.headline}</h2>
            <p className="mt-4" style={{ color: sub }}>{content.sub}</p>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {features.map((f, i) => (
              <div key={i} className="rounded-2xl border p-6" style={{ background: cardBg, borderColor: cardBorder, backdropFilter: 'blur(8px)' }}>
                <div className="size-9 rounded-lg mb-5 grid place-items-center" style={{ background: f.c }}>
                  <div className="size-3 rounded-sm bg-white/90" />
                </div>
                <h3 className="text-lg font-semibold" style={{ color: fg }}>{f.t}</h3>
                <p className="mt-2 text-sm leading-relaxed" style={{ color: sub }}>{f.b}</p>
              </div>
            ))}
          </div>
        </div>
      );
    },
    generateMarkup: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const cardBg = dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.7)';
      const cardBorder = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
      const card = (t, b, c) => `      <div class="rounded-2xl border p-6 backdrop-blur" style="background:${cardBg};border-color:${cardBorder}">
        <div class="size-9 rounded-lg mb-5 grid place-items-center" style="background:${c}">
          <div class="size-3 rounded-sm bg-white/90"></div>
        </div>
        <h3 class="text-lg font-semibold" style="color:${fg}">${t}</h3>
        <p class="mt-2 text-sm leading-relaxed" style="color:${sub}">${b}</p>
      </div>`;
      return `  <div class="relative z-10 mx-auto max-w-6xl px-6 py-24">
    <div class="text-center mb-14 max-w-2xl mx-auto">
      <h2 class="text-4xl md:text-5xl font-semibold tracking-tight" style="color:${fg};letter-spacing:-0.02em">${content.headline}</h2>
      <p class="mt-4" style="color:${sub}">${content.sub}</p>
    </div>
    <div class="grid md:grid-cols-3 gap-4">
${card(content.f1Title, content.f1Body, palette.primary)}
${card(content.f2Title, content.f2Body, palette.secondary)}
${card(content.f3Title, content.f3Body, palette.accent)}
    </div>
  </div>`;
    },
  },

  {
    id: 'pricing-teaser',
    name: 'Pricing teaser',
    defaults: {
      headline: 'Pricing that respects your wallet.',
      sub: 'Pay monthly, cancel any time. Volume discounts at 10+ seats.',
      tier1Name: 'Hobby',
      tier1Price: '$0',
      tier1Cta: 'Start free',
      tier2Name: 'Pro',
      tier2Price: '$12',
      tier2Cta: 'Get Pro',
      tier3Name: 'Team',
      tier3Price: '$48',
      tier3Cta: 'Contact us',
    },
    render: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const cardBg = dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.7)';
      const cardBorder = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
      const accentText = bestTextColor(palette.primary);
      const tiers = [
        { name: content.tier1Name, price: content.tier1Price, cta: content.tier1Cta, highlight: false },
        { name: content.tier2Name, price: content.tier2Price, cta: content.tier2Cta, highlight: true },
        { name: content.tier3Name, price: content.tier3Price, cta: content.tier3Cta, highlight: false },
      ];
      return (
        <div className="relative z-10 mx-auto max-w-5xl px-6 py-24">
          <div className="text-center mb-14 max-w-xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-semibold tracking-tight" style={{ color: fg, letterSpacing: '-0.02em' }}>{content.headline}</h2>
            <p className="mt-4" style={{ color: sub }}>{content.sub}</p>
          </div>
          <div className="grid md:grid-cols-3 gap-4">
            {tiers.map((t, i) => (
              <div key={i} className="rounded-2xl p-6 backdrop-blur"
                style={{
                  background: t.highlight ? hexWithAlpha(palette.primary, 0.12) : cardBg,
                  border: `1px solid ${t.highlight ? palette.primary : cardBorder}`,
                }}>
                <div className="text-xs font-mono tracking-wider uppercase" style={{ color: t.highlight ? palette.primary : sub }}>{t.name}</div>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-4xl font-semibold" style={{ color: fg }}>{t.price}</span>
                  <span className="text-sm" style={{ color: sub }}>/mo</span>
                </div>
                <ul className="mt-5 space-y-2 text-sm" style={{ color: sub }}>
                  <li>• Unlimited backgrounds</li>
                  <li>• Copy as HTML / JSX</li>
                  <li>• Save favorites</li>
                </ul>
                <button className="mt-6 w-full py-2.5 rounded-lg text-sm font-medium"
                  style={t.highlight
                    ? { background: palette.primary, color: accentText }
                    : { background: 'transparent', color: fg, border: `1px solid ${dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)'}` }}>
                  {t.cta}
                </button>
              </div>
            ))}
          </div>
        </div>
      );
    },
    generateMarkup: ({ palette, content, dark }) => {
      const fg = dark ? '#f5f5f7' : '#0a0a0b';
      const sub = dark ? 'rgba(245,245,247,.7)' : 'rgba(10,10,11,.65)';
      const cardBg = dark ? 'rgba(255,255,255,.04)' : 'rgba(255,255,255,.7)';
      const cardBorder = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
      const accentText = bestTextColor(palette.primary);
      const tier = (name, price, cta, hi) => `      <div class="rounded-2xl p-6 backdrop-blur" style="background:${hi ? hexWithAlpha(palette.primary, 0.12) : cardBg};border:1px solid ${hi ? palette.primary : cardBorder}">
        <div class="text-xs font-mono tracking-wider uppercase" style="color:${hi ? palette.primary : sub}">${name}</div>
        <div class="mt-4 flex items-baseline gap-1">
          <span class="text-4xl font-semibold" style="color:${fg}">${price}</span>
          <span class="text-sm" style="color:${sub}">/mo</span>
        </div>
        <ul class="mt-5 space-y-2 text-sm" style="color:${sub}">
          <li>• Unlimited backgrounds</li>
          <li>• Copy as HTML / JSX</li>
          <li>• Save favorites</li>
        </ul>
        <button class="mt-6 w-full py-2.5 rounded-lg text-sm font-medium" style="${hi ? `background:${palette.primary};color:${accentText}` : `background:transparent;color:${fg};border:1px solid ${dark ? 'rgba(255,255,255,.18)' : 'rgba(0,0,0,.15)'}`}">${cta}</button>
      </div>`;
      return `  <div class="relative z-10 mx-auto max-w-5xl px-6 py-24">
    <div class="text-center mb-14 max-w-xl mx-auto">
      <h2 class="text-4xl md:text-5xl font-semibold tracking-tight" style="color:${fg};letter-spacing:-0.02em">${content.headline}</h2>
      <p class="mt-4" style="color:${sub}">${content.sub}</p>
    </div>
    <div class="grid md:grid-cols-3 gap-4">
${tier(content.tier1Name, content.tier1Price, content.tier1Cta, false)}
${tier(content.tier2Name, content.tier2Price, content.tier2Cta, true)}
${tier(content.tier3Name, content.tier3Price, content.tier3Cta, false)}
    </div>
  </div>`;
    },
  },
];

window.SECTIONS = SECTIONS;
