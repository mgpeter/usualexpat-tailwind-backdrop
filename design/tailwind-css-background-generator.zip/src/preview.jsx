// Live preview surface. Renders the chosen background + section composition.

const Preview = ({ bg, section, palette, content, dark, viewport }) => {
  const surfaceRef = React.useRef(null);
  const [mouse, setMouse] = React.useState({ x: 50, y: 30 });

  const handleMouse = (e) => {
    if (bg.id !== 'anim-spotlight') return;
    const rect = surfaceRef.current?.getBoundingClientRect();
    if (!rect) return;
    setMouse({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  };

  const rendered = bg.def.render(bg.opts, palette, { mouseX: mouse.x, mouseY: mouse.y });

  // Width target for preview
  const widthClass = {
    desktop: 'w-full',
    tablet: 'w-[820px] max-w-full',
    mobile: 'w-[400px] max-w-full',
  }[viewport] || 'w-full';

  return (
    <div className="h-full w-full overflow-auto p-6 flex items-start justify-center">
      <div className={cx("rounded-2xl overflow-hidden border shadow-2xl transition-all my-auto", widthClass)}
        style={{ borderColor: 'var(--border-2)' }}>
        {/* Mock browser chrome */}
        <div className="flex items-center gap-2 px-4 py-2.5 border-b" style={{ borderColor: 'var(--border)', background: dark ? '#0a0a0b' : '#f5f5f7' }}>
          <div className="flex gap-1.5">
            <div className="size-2.5 rounded-full" style={{ background: '#ff5f57' }} />
            <div className="size-2.5 rounded-full" style={{ background: '#febc2e' }} />
            <div className="size-2.5 rounded-full" style={{ background: '#28c840' }} />
          </div>
          <div className="flex-1 mx-4 px-3 py-1 rounded-md text-xs font-mono"
            style={{ background: dark ? '#161618' : '#e7e7ea', color: dark ? '#9b9ba3' : '#5e5e68' }}>
            yourdomain.com
          </div>
        </div>
        {/* The actual section surface */}
        <div
          ref={surfaceRef}
          onMouseMove={handleMouse}
          className="relative"
          style={{ ...rendered.style }}
        >
          {rendered.layers ? (
            <div className="absolute inset-0 pointer-events-none">{rendered.layers}</div>
          ) : null}
          {section.def.render({ palette, content, dark })}
        </div>
      </div>
    </div>
  );
};

window.Preview = Preview;
