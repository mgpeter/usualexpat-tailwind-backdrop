// Utilities + shared state helpers

const cx = (...args) => args.filter(Boolean).join(' ');

// Hex helpers
function hexToRgb(hex) {
  if (!hex) return { r: 0, g: 0, b: 0 };
  const h = hex.replace('#', '');
  const v = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
  const num = parseInt(v, 16);
  return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}
function rgbToHex(r, g, b) {
  const c = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, '0');
  return '#' + c(r) + c(g) + c(b);
}
function hexWithAlpha(hex, a) {
  const { r, g, b } = hexToRgb(hex);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
function lighten(hex, amount = 0.15) {
  const { r, g, b } = hexToRgb(hex);
  return rgbToHex(r + (255 - r) * amount, g + (255 - g) * amount, b + (255 - b) * amount);
}
function darken(hex, amount = 0.15) {
  const { r, g, b } = hexToRgb(hex);
  return rgbToHex(r * (1 - amount), g * (1 - amount), b * (1 - amount));
}
function relativeLuminance(hex) {
  const { r, g, b } = hexToRgb(hex);
  const f = (c) => {
    c /= 255;
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}
function bestTextColor(bgHex) {
  return relativeLuminance(bgHex) > 0.5 ? '#0a0a0b' : '#f5f5f7';
}

// Clipboard
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch {}
    document.body.removeChild(ta);
    return true;
  }
}

// Local storage
function lsGet(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch { return fallback; }
}
function lsSet(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

// Format HTML output with simple syntax highlighting tokens
function highlightHtml(src) {
  // Escape HTML entities
  let out = src.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  // comments
  out = out.replace(/&lt;!--([\s\S]*?)--&gt;/g, (m) => `<span class="tk-cmt">${m}</span>`);
  // <style> blocks: highlight as keys/values lightly
  // tags
  out = out.replace(/(&lt;\/?)([a-zA-Z][\w-]*)/g, (m, lt, name) => `${lt}<span class="tk-tag">${name}</span>`);
  // attributes
  out = out.replace(/(\s)([a-zA-Z_:][\w:.-]*)(=)(&quot;)([^&]*?)(&quot;)/g,
    (m, sp, name, eq, q1, val, q2) =>
      `${sp}<span class="tk-attr">${name}</span>${eq}<span class="tk-str">${q1}${val}${q2}</span>`
  );
  return out;
}

Object.assign(window, {
  cx, hexToRgb, rgbToHex, hexWithAlpha, lighten, darken, relativeLuminance,
  bestTextColor, copyText, lsGet, lsSet, highlightHtml,
});
