// Left controls panel: section picker, background picker, color palette, advanced controls

const SectionTab = ({ icon: Icon, label, active, onClick }) => (
  <button onClick={onClick}
    className={cx("flex-1 px-3 py-2 rounded-md text-xs font-medium flex items-center justify-center gap-1.5 transition-colors",
      active ? "bg-[#1f1f23] text-[var(--fg)]" : "text-[var(--fg-dim)] hover:text-[var(--fg)]")}>
    {Icon && <Icon size={13} />}
    {label}
  </button>
);

const Label = ({ children, hint }) => (
  <div className="flex items-baseline justify-between mb-2">
    <div className="text-[11px] font-mono tracking-wider uppercase text-[var(--fg-dim)]">{children}</div>
    {hint && <div className="text-[10px] font-mono text-[var(--fg-faint)]">{hint}</div>}
  </div>
);

const Slider = ({ value, onChange, min, max, step, suffix }) => (
  <div className="flex items-center gap-3">
    <input type="range" className="bd-range flex-1" min={min} max={max} step={step} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} />
    <div className="text-[11px] font-mono text-[var(--fg-dim)] tabular-nums w-14 text-right">
      {Number.isInteger(step) ? Math.round(value) : value.toFixed(2)}{suffix || ''}
    </div>
  </div>
);

const ToggleRow = ({ label, value, onChange }) => (
  <button onClick={() => onChange(!value)}
    className="w-full flex items-center justify-between py-1.5">
    <span className="text-xs text-[var(--fg)]">{label}</span>
    <div className={cx("w-8 h-[18px] rounded-full p-[2px] transition-colors", value ? "bg-[var(--accent)]" : "bg-[#2a2a30]")}>
      <div className={cx("w-[14px] h-[14px] rounded-full bg-white transition-transform", value && "translate-x-[14px]")} />
    </div>
  </button>
);

const ColorRow = ({ label, value, onChange }) => (
  <div className="flex items-center justify-between gap-2 py-1">
    <div className="text-xs text-[var(--fg)]">{label}</div>
    <div className="flex items-center gap-2">
      <input type="text" value={value} onChange={(e) => onChange(e.target.value)}
        className="w-20 bg-[#0a0a0b] border border-[var(--border-2)] rounded-md px-2 py-1 text-[11px] font-mono uppercase text-[var(--fg-dim)] outline-none focus:border-[var(--accent)]" />
      <input type="color" className="bd-color" value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  </div>
);

const Section = ({ title, children, defaultOpen = true, badge }) => {
  const [open, setOpen] = React.useState(defaultOpen);
  return (
    <div className="border-b border-[var(--border)]">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between px-5 py-3.5 hover:bg-[#0f0f11]">
        <div className="flex items-center gap-2">
          <Icons.chevronDown size={12} className={cx("transition-transform text-[var(--fg-faint)]", !open && "-rotate-90")} />
          <span className="text-[11px] font-mono tracking-wider uppercase text-[var(--fg-dim)]">{title}</span>
          {badge && <span className="text-[10px] font-mono text-[var(--fg-faint)]">{badge}</span>}
        </div>
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  );
};

const Controls = ({ state, set }) => {
  const { sectionId, bgId, bgOpts, palette, content, dark, viewport, favorites } = state;
  const sectionDef = SECTIONS.find(s => s.id === sectionId);

  // Group backgrounds by category
  const byCat = BG_CATEGORIES.map(cat => ({
    ...cat,
    items: BACKGROUNDS.filter(b => b.category === cat.id),
  }));

  const setBg = (id) => {
    const def = BACKGROUNDS.find(b => b.id === id);
    set({ bgId: id, bgOpts: { ...def.defaults } });
  };

  const setSection = (id) => {
    const def = SECTIONS.find(s => s.id === id);
    set({ sectionId: id, content: { ...def.defaults } });
  };

  const randomize = () => {
    const bgList = BACKGROUNDS;
    const def = bgList[Math.floor(Math.random() * bgList.length)];
    // Random colors with same chroma
    const hues = [Math.random() * 360, Math.random() * 360, Math.random() * 360];
    const toHex = (h) => {
      // approx oklch -> rgb via canvas
      const div = document.createElement('div');
      div.style.color = `oklch(0.7 0.18 ${h})`;
      document.body.appendChild(div);
      const rgb = getComputedStyle(div).color;
      document.body.removeChild(div);
      const m = rgb.match(/\d+/g);
      return rgbToHex(+m[0], +m[1], +m[2]);
    };
    set({
      bgId: def.id,
      bgOpts: { ...def.defaults },
      palette: { ...palette, primary: toHex(hues[0]), secondary: toHex(hues[1]), accent: toHex(hues[2]) }
    });
  };

  const isFav = favorites.some(f => f.bgId === bgId && f.sectionId === sectionId);
  const toggleFav = () => {
    const id = `${sectionId}+${bgId}+${Date.now()}`;
    const next = isFav
      ? favorites.filter(f => !(f.bgId === bgId && f.sectionId === sectionId))
      : [...favorites, { id, bgId, sectionId, bgOpts: { ...bgOpts }, palette: { ...palette }, dark }];
    set({ favorites: next });
    lsSet('bd-favorites', next);
  };

  const params = BG_PARAMS[bgId] || [];

  return (
    <div className="h-full flex flex-col">
      {/* Top brand bar */}
      <div className="px-5 py-4 border-b border-[var(--border)] flex items-center gap-3">
        <div className="size-7 rounded-md grid place-items-center" style={{ background: 'linear-gradient(135deg, var(--accent), var(--accent-2))' }}>
          <Icons.layers size={14} className="text-black" />
        </div>
        <div className="flex-1">
          <div className="text-[15px] font-semibold tracking-tight">Backdrop</div>
          <div className="text-[10px] font-mono text-[var(--fg-faint)] tracking-wider">v1.0 · TAILWIND GENERATOR</div>
        </div>
        <button onClick={randomize}
          className="bd-tip text-[var(--fg-dim)] hover:text-[var(--fg)] p-1.5 rounded-md hover:bg-[#1f1f23]"
          data-tip="Randomize">
          <Icons.shuffle size={14} />
        </button>
        <button onClick={toggleFav}
          className="bd-tip text-[var(--fg-dim)] hover:text-[var(--fg)] p-1.5 rounded-md hover:bg-[#1f1f23]"
          data-tip={isFav ? "Unsave" : "Save"}>
          {isFav ? <Icons.starFilled size={14} className="text-[var(--accent)]" /> : <Icons.star size={14} />}
        </button>
      </div>

      {/* Scroll content */}
      <div className="flex-1 overflow-y-auto">

        {/* SECTION */}
        <Section title="01 · Section" badge={`${SECTIONS.length} templates`}>
          <div className="grid grid-cols-1 gap-1.5">
            {SECTIONS.map(s => (
              <button key={s.id} onClick={() => setSection(s.id)}
                className={cx("text-left px-3 py-2.5 rounded-md text-xs flex items-center justify-between border transition-colors",
                  sectionId === s.id
                    ? "bg-[#1a1a1d] border-[var(--border-2)] text-[var(--fg)]"
                    : "bg-transparent border-transparent text-[var(--fg-dim)] hover:border-[var(--border)] hover:text-[var(--fg)]")}>
                <span>{s.name}</span>
                {sectionId === s.id && <Icons.check size={12} className="text-[var(--accent)]" />}
              </button>
            ))}
          </div>
        </Section>

        {/* BACKGROUND */}
        <Section title="02 · Background" badge={`${BACKGROUNDS.length} styles`}>
          <div className="space-y-4">
            {byCat.map(cat => (
              <div key={cat.id}>
                <div className="text-[10px] font-mono text-[var(--fg-dim)] mb-2 tracking-[0.15em] font-semibold">{cat.label.toUpperCase()}</div>
                <div className="grid grid-cols-2 gap-1.5">
                  {cat.items.map(b => (
                    <BgChip key={b.id} bg={b} palette={palette} active={bgId === b.id} onClick={() => setBg(b.id)} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* PALETTE */}
        <Section title="03 · Palette">
          <div className="space-y-1">
            <ColorRow label="Primary" value={palette.primary} onChange={(v) => set({ palette: { ...palette, primary: v } })} />
            <ColorRow label="Secondary" value={palette.secondary} onChange={(v) => set({ palette: { ...palette, secondary: v } })} />
            <ColorRow label="Accent" value={palette.accent} onChange={(v) => set({ palette: { ...palette, accent: v } })} />
            <div className="h-px bg-[var(--border)] my-3" />
            <ColorRow label="Background" value={palette.bg} onChange={(v) => set({ palette: { ...palette, bg: v } })} />
            <ColorRow label="Foreground" value={palette.fg} onChange={(v) => set({ palette: { ...palette, fg: v } })} />
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            {[
              { name: 'Teal',   p: '#14b8a6', s: '#0ea5e9', a: '#a855f7' },
              { name: 'Sunset', p: '#f97316', s: '#ec4899', a: '#8b5cf6' },
              { name: 'Forest', p: '#22c55e', s: '#10b981', a: '#84cc16' },
              { name: 'Ocean',  p: '#3b82f6', s: '#06b6d4', a: '#6366f1' },
              { name: 'Rose',   p: '#f43f5e', s: '#ec4899', a: '#f59e0b' },
              { name: 'Mono',   p: '#71717a', s: '#a1a1aa', a: '#52525b' },
            ].map(preset => (
              <button key={preset.name}
                onClick={() => set({ palette: { ...palette, primary: preset.p, secondary: preset.s, accent: preset.a } })}
                className="rounded-md border border-[var(--border)] p-1.5 hover:border-[var(--border-2)] flex flex-col gap-1 group">
                <div className="flex gap-0.5 h-5 rounded overflow-hidden">
                  <div style={{ background: preset.p }} className="flex-1" />
                  <div style={{ background: preset.s }} className="flex-1" />
                  <div style={{ background: preset.a }} className="flex-1" />
                </div>
                <div className="text-[10px] font-mono text-[var(--fg-faint)] group-hover:text-[var(--fg-dim)]">{preset.name}</div>
              </button>
            ))}
          </div>
        </Section>

        {/* ADVANCED */}
        {params.length > 0 && (
          <Section title="04 · Advanced" defaultOpen={false} badge={`${params.length} options`}>
            <div className="space-y-4">
              {params.map(p => (
                <div key={p.key}>
                  {p.kind === 'slider' ? (
                    <>
                      <Label hint={p.suffix ? `${(bgOpts[p.key] ?? 0).toString()}${p.suffix}` : null}>{p.label}</Label>
                      <Slider value={bgOpts[p.key] ?? p.min} onChange={(v) => set({ bgOpts: { ...bgOpts, [p.key]: v } })}
                        min={p.min} max={p.max} step={p.step} suffix={p.suffix} />
                    </>
                  ) : p.kind === 'toggle' ? (
                    <ToggleRow label={p.label} value={!!bgOpts[p.key]} onChange={(v) => set({ bgOpts: { ...bgOpts, [p.key]: v } })} />
                  ) : null}
                </div>
              ))}
              {/* Color overrides */}
              <div className="pt-3 border-t border-[var(--border)] space-y-1">
                <Label>Color overrides</Label>
                <ColorRow label="Color 1" value={bgOpts.c1 || palette.primary} onChange={(v) => set({ bgOpts: { ...bgOpts, c1: v } })} />
                <ColorRow label="Color 2" value={bgOpts.c2 || palette.secondary} onChange={(v) => set({ bgOpts: { ...bgOpts, c2: v } })} />
                <ColorRow label="Color 3" value={bgOpts.c3 || palette.accent} onChange={(v) => set({ bgOpts: { ...bgOpts, c3: v } })} />
              </div>
            </div>
          </Section>
        )}

        {/* CONTENT */}
        <Section title="05 · Content" defaultOpen={false}>
          <div className="space-y-3">
            {Object.entries(content).map(([k, v]) => (
              <div key={k}>
                <Label>{k.replace(/([A-Z])/g, ' $1').trim()}</Label>
                {v.length > 60 ? (
                  <textarea rows={2} value={v} onChange={(e) => set({ content: { ...content, [k]: e.target.value } })}
                    className="w-full bg-[#0a0a0b] border border-[var(--border-2)] rounded-md px-2.5 py-2 text-xs text-[var(--fg)] outline-none focus:border-[var(--accent)] resize-none" />
                ) : (
                  <input type="text" value={v} onChange={(e) => set({ content: { ...content, [k]: e.target.value } })}
                    className="w-full bg-[#0a0a0b] border border-[var(--border-2)] rounded-md px-2.5 py-1.5 text-xs text-[var(--fg)] outline-none focus:border-[var(--accent)]" />
                )}
              </div>
            ))}
          </div>
        </Section>

        {/* FAVORITES */}
        {favorites.length > 0 && (
          <Section title="06 · Favorites" badge={`${favorites.length} saved`}>
            <div className="grid grid-cols-2 gap-1.5">
              {favorites.map(f => {
                const def = BACKGROUNDS.find(b => b.id === f.bgId);
                if (!def) return null;
                return (
                  <div key={f.id} className="relative group">
                    <BgChip bg={def} palette={f.palette} active={false}
                      onClick={() => set({ bgId: f.bgId, sectionId: f.sectionId, bgOpts: { ...f.bgOpts }, palette: { ...f.palette } })} />
                    <button onClick={(e) => {
                      e.stopPropagation();
                      const next = favorites.filter(x => x.id !== f.id);
                      set({ favorites: next }); lsSet('bd-favorites', next);
                    }}
                      className="absolute top-1 right-1 p-0.5 rounded bg-black/60 text-white/80 opacity-0 group-hover:opacity-100">
                      <Icons.x size={10} />
                    </button>
                  </div>
                );
              })}
            </div>
          </Section>
        )}
      </div>
    </div>
  );
};

// Mini preview chip for picking a background
const BgChip = ({ bg, palette, active, onClick }) => {
  const rendered = bg.render(bg.defaults, palette);
  return (
    <button onClick={onClick}
      className={cx("relative aspect-[3/2] rounded-md overflow-hidden border transition-all group",
        active ? "border-[var(--accent)] ring-2 ring-[var(--accent)]/30" : "border-[var(--border)] hover:border-[var(--border-2)]")}>
      <div className="absolute inset-0" style={rendered.style}>
        {rendered.layers && <div className="absolute inset-0">{rendered.layers}</div>}
      </div>
      <div className="absolute inset-x-0 bottom-0 px-1.5 py-1 bg-gradient-to-t from-black/85 to-transparent">
        <div className="text-[9px] font-mono text-white/95 truncate text-left">{bg.name}</div>
      </div>
      {active && (
        <div className="absolute top-1 right-1 size-3.5 rounded-full bg-[var(--accent)] grid place-items-center">
          <Icons.check size={9} className="text-black" strokeWidth={3} />
        </div>
      )}
    </button>
  );
};

window.Controls = Controls;
