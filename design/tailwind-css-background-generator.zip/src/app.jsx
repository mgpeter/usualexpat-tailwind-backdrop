// Main App: split-screen layout, state management, tweaks panel

const DEFAULT_PALETTE = {
  primary: '#14b8a6',
  secondary: '#0ea5e9',
  accent: '#a855f7',
  bg: '#0a0a0b',
  fg: '#f5f5f7',
};

const APP_TWEAKS = /*EDITMODE-BEGIN*/{
  "appAccent": "#14b8a6",
  "appFont": "Inter",
  "panelWidth": 380,
  "showGrain": false
}/*EDITMODE-END*/;

function App() {
  const initialFavs = lsGet('bd-favorites', []);

  const [state, setState] = React.useState(() => ({
    sectionId: 'hero-centered',
    bgId: 'mesh-soft',
    bgOpts: { ...BACKGROUNDS.find(b => b.id === 'mesh-soft').defaults },
    palette: { ...DEFAULT_PALETTE },
    content: { ...SECTIONS.find(s => s.id === 'hero-centered').defaults },
    dark: true,
    viewport: 'desktop',
    favorites: initialFavs,
  }));

  const set = (patch) => setState(s => ({ ...s, ...patch }));

  const [codeOpen, setCodeOpen] = React.useState(true);
  const [toast, setToast] = React.useState({ visible: false, msg: '' });
  const toastTimer = React.useRef(null);

  const bgDef = BACKGROUNDS.find(b => b.id === state.bgId);
  const sectionDef = SECTIONS.find(s => s.id === state.sectionId);

  const html = buildOutput({
    bgDef, bgOpts: state.bgOpts, sectionDef,
    palette: state.palette, content: state.content, dark: state.dark
  });

  const handleCopy = async () => {
    await copyText(html);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    setToast({ visible: true, msg: 'Copied to clipboard' });
    toastTimer.current = setTimeout(() => setToast({ visible: false, msg: '' }), 2000);
  };

  // Resizable left panel
  const [panelWidth, setPanelWidth] = React.useState(380);
  const dragRef = React.useRef(null);
  const onDragStart = (e) => {
    e.preventDefault();
    dragRef.current = { startX: e.clientX, startW: panelWidth };
    document.body.style.userSelect = 'none';
    const onMove = (ev) => {
      const dx = ev.clientX - dragRef.current.startX;
      setPanelWidth(Math.max(320, Math.min(560, dragRef.current.startW + dx)));
    };
    const onUp = () => {
      document.body.style.userSelect = '';
      document.removeEventListener('mousemove', onMove);
      document.removeEventListener('mouseup', onUp);
    };
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onUp);
  };

  // Tweaks panel for app aesthetic
  const tweaks = useTweaks ? useTweaks(APP_TWEAKS) : [APP_TWEAKS, () => {}];
  const [tw, setTw] = tweaks;

  // Apply tweaks
  React.useEffect(() => {
    document.documentElement.style.setProperty('--accent', tw.appAccent || '#14b8a6');
    document.body.style.fontFamily = `'${tw.appFont || 'Inter'}', system-ui, sans-serif`;
  }, [tw.appAccent, tw.appFont]);

  return (
    <div className="h-screen w-screen flex flex-col bg-[var(--bg)] text-[var(--fg)] overflow-hidden">
      {/* Optional grain overlay */}
      {tw.showGrain && (
        <div className="pointer-events-none fixed inset-0 z-50 opacity-[0.04] mix-blend-overlay"
          style={{ backgroundImage: `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence baseFrequency='0.9' numOctaves='3'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")` }} />
      )}

      {/* Top bar */}
      <div className="h-12 flex items-center justify-between px-5 border-b border-[var(--border)] bg-[var(--panel)] shrink-0">
        <div className="flex items-center gap-3 text-[11px] font-mono text-[var(--fg-faint)] tracking-wider">
          <span>EDITING</span>
          <span className="text-[var(--fg-dim)]">/</span>
          <span className="text-[var(--fg-dim)]">{sectionDef.name.toUpperCase()}</span>
          <span className="text-[var(--fg-dim)]">·</span>
          <span style={{ color: 'var(--accent)' }}>{bgDef.name.toUpperCase()}</span>
        </div>
        <div className="flex items-center gap-3">
          <ViewportToggle value={state.viewport} onChange={(v) => set({ viewport: v })} />
          <DarkToggle value={state.dark} onChange={(v) => set({ dark: v })} />
          <div className="h-6 w-px bg-[var(--border)]" />
          <button onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-[12px] font-medium bg-[var(--accent)] text-black hover:opacity-90">
            <Icons.copy size={12} />
            Copy code
          </button>
        </div>
      </div>

      {/* Main split */}
      <div className="flex-1 flex min-h-0">
        {/* Controls */}
        <div className="bg-[var(--panel)] border-r border-[var(--border)] shrink-0" style={{ width: panelWidth }}>
          <Controls state={state} set={set} />
        </div>

        {/* Resizer */}
        <div onMouseDown={onDragStart} className="bd-resize w-px bg-[var(--border)] shrink-0 hover:w-1 transition-[width]" />

        {/* Right column: preview + code */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 min-h-0 relative" style={{ background: '#050506' }}>
            {/* Subtle grid behind preview */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.4]"
              style={{
                backgroundImage: `radial-gradient(${hexWithAlpha('#ffffff', 0.04)} 1px, transparent 1px)`,
                backgroundSize: '24px 24px',
              }} />
            <Preview
              bg={{ id: state.bgId, def: bgDef, opts: state.bgOpts }}
              section={{ def: sectionDef }}
              palette={state.palette}
              content={state.content}
              dark={state.dark}
              viewport={state.viewport}
            />
          </div>
          <CodePanel html={html} onCopy={handleCopy} open={codeOpen} onToggle={() => setCodeOpen(!codeOpen)} />
        </div>
      </div>

      {/* Toast */}
      <Toast visible={toast.visible} message={toast.msg} />

      {/* Tweaks Panel */}
      {typeof TweaksPanel !== 'undefined' && (
        <TweaksPanel title="Tweaks">
          <TweakSection title="App appearance">
            <TweakColor label="App accent" value={tw.appAccent} onChange={(v) => setTw('appAccent', v)} />
            <TweakSelect label="UI font" value={tw.appFont} onChange={(v) => setTw('appFont', v)}
              options={['Inter', 'JetBrains Mono', 'system-ui']} />
            <TweakSlider label="Controls width" value={panelWidth} onChange={setPanelWidth} min={320} max={560} step={10} suffix="px" />
            <TweakToggle label="Film grain overlay" value={tw.showGrain} onChange={(v) => setTw('showGrain', v)} />
          </TweakSection>
          <TweakSection title="Reset">
            <TweakButton label="Clear favorites" onClick={() => { lsSet('bd-favorites', []); set({ favorites: [] }); }} />
          </TweakSection>
        </TweaksPanel>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
